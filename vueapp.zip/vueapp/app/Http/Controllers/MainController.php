<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

public function storeItem(Request $request) {
    $data = new Data ();
    $data->firstname = $request->firstname;
    $data->lastname = $request->lastname;
    $data->email = $request->email;
    $data->phoneno = $request->phoneno;
    $data->gender = $request->gender;
    $data->address = $request->address;
    $data->save ();
    return $data;
}

public function readItems() {
    $data = Data::all ();
    return $data;
}

public function editItem(Request $request, $id){
    $data =Data::where('id', $id)->first();
    $data->firstname = $request->get('val_1');
    $data->lastname = $request->get('val_2');
    $data->email = $request->get('val_3');
    $data->phoneno = $request->get('val_4');
    $data->gender = $request->get('val_5');	
    $data->address = $request->get('val_6');	
    $data->save();
    return $data;
}

public function deleteItem(Request $request) {
    $data = Data::find ( $request->id )->delete ();
}
