<?php

class Data extends Model {
    protected $table = "vueCrudData";
    public $timestamps = false;
}