
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i);
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default));

Vue.component('example-component', require('./components/ExampleComponent.vue').default);

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */
createItem: function createItem() {
      var _this = this;
      var input = this.newItem;
      
      if (input['firstname'] == '' || input['lastname'] == '' || input['email'] == '' || input['phoneno'] == '' || input['gender'] == '' || input['address'] == '' ) {
        this.hasError = false;
      } else {
        this.hasError = true;
        axios.post('/vueitems', input).then(function (response) {
          _this.newItem = { 'firstname': '' };
          _this.getVueItems();
        });
      }
    }
	
mounted: function mounted() {
  this.getVueItems();
},

getVueItems: function getVueItems() {
  var _this = this;
 
  axios.get('/vueitems').then(function (response) {
    _this.items = response.data;
  });
}

editItem: function(){
     var i_val = document.getElementById('e_id');
     var f_val = document.getElementById('e_firstname');
     var l_val = document.getElementById('e_lastname');
     var e_val = document.getElementById('e_email');
     var p_val = document.getElementById('e_phoneno');
     var g_val = document.getElementById('e_gender');
     var a_val = document.getElementById('e_address');
	 
      axios.post('/edititems/' + i_val.value, {val_1: f_val.value, val_2: l_val.value,val_3: e_val.value,val_4: p_val.value,val_5: g_val.value,val_6: a_val.value })
        .then(response => {
          this.getVueItems();
          this.showModal=false
        });   
}

deleteItem: function deleteItem(item) {
  var _this = this;
  axios.post('/vueitems/' + item.id).then(function (response) {
    _this.getVueItems();
    _this.hasDeleted = false   
  });
}

const app = new Vue({
    el: '#vue-crud-wrapper',
	data: { ...     items: [],
    hasError: true,
    newItem: { 'firstname': '','lastname': '','email': '','phoneno': '','gender': '','address': '' },},
	methods: {createItem,mounted,getVueItems,editItem,deleteItem}
});
