<?php
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
	</head>
    <body>
		<div id="vue-crud-wrapper">
			<div class="form-group">
				<label for="firstname">First Name:</label>
				<input type="text" class="form-control" id="firstname" name="firstname" 
        required v-model="newItem.firstname" placeholder=" Enter your first name">
			</div>
			<div class="form-group">
				<label for="lastname">Last Name:</label>
				<input type="text" class="form-control" id="lastname" name="lastname" 
        required v-model="newItem.lastname" placeholder=" Enter your last name">
			</div>
			<div class="form-group">
				<label for="email">Email:</label>
				<input type="text" class="form-control" id="email" name="email" 
        required v-model="newItem.email" placeholder=" Enter your email">
			</div>
			<div class="form-group">
				<label for="phoneno">Phone no:</label>
				<input type="text" class="form-control" id="phoneno" name="phoneno" 
         v-model="newItem.phoneno" placeholder=" Enter your phone number">
			</div>
			<div class="form-group">
				<label for="gender">Gender:</label>
				<input type="text" class="form-control" id="gender" name="gender" 
        required v-model="newItem.gender" placeholder=" Enter your gender">
			</div>
			<div class="form-group">
				<label for="address">Address:</label>
				<input type="text" class="form-control" id="address" name="address"
    required v-model="newItem.address" placeholder=" Enter your address">
			</div>
 
			<button class="btn btn-primary" @click.prevent="createItem()" id="firstname" name="firstname">
<span class="glyphicon glyphicon-plus"></span> ADD
			</button>
			<p class="text-center alert alert-danger"
    v-bind:class="{ hidden: hasError }">Please fill in your first name, last name, email, gender and address </p>
		
			<div class="table table-borderless" id="table">
    <table class="table table-borderless" id="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tr v-for="item in items">
            <td>@{{ item.id }}</td>
            <td>@{{ item.firstname }}</td>
            <td>@{{ item.lastname }}</td>
            <td>@{{ item.email }}</td>
            <td>@{{ item.phoneno }}</td>			
            <td>@{{ item.gender }}</td>			
            <td>@{{ item.address }}</td>
            
            <td id="show-modal" @click="showModal=true; setVal(item.id, item.firstname, item.lastname, item.email, item.phoneno, item.gender, item.address)"  class="btn btn-info" ><span
            class="glyphicon glyphicon-pencil"></span></td>
            <td @click.prevent="deleteItem(item)" class="btn btn-danger"><span
                class="glyphicon glyphicon-trash"></span></td>
        </tr>
    </table>
</div>
		
		</div>
	</body>

<modal v-if="showModal" @close="showModal=false">
    <h3 slot="header">Edit guest</h3>
    <div slot="body">
        
        <input type="hidden" disabled class="form-control" id="e_id" name="id"
                required  :value="this.e_id">
        First Name: <input type="text" class="form-control" id="e_firstname" name="firstname"
                required  :value="this.e_firstname">
        Last Name: <input type="text" class="form-control" id="e_lastname" name="lastname"
                required  :value="this.e_lastname">
		Email: <input type="text" class="form-control" id="e_email" name="email"
        required  :value="this.e_email">
        Phone number: <input type="text" class="form-control" id="e_phoneno" name="phoneno"
                required  :value="this.e_phoneno">
        Gender: <input type="text" class="form-control" id="e_gender" name="gender"
                required  :value="this.e_gender">
        Address: <input type="text" class="form-control" id="e_address" name="address"
        required  :value="this.e_address">
        
      
    </div>
    <div slot="footer">
        <button class="btn btn-default" @click="showModal = false">
        Cancel
      </button>
      
      <button class="btn btn-info" @click="editItem()">
        Update
      </button>
    </div>
</modal>
</html>
;?>